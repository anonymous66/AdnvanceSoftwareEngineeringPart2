
public class testException extends Exception{
	
	public testException (){
		super("fgdfggghsdghkdfjgdfbgkdffa");
	}
	
}